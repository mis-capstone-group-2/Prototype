﻿
Partial Class DetailsView
    Inherits System.Web.UI.Page

End Class
