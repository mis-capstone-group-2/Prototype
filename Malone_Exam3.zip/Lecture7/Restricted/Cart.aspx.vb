﻿
Partial Class Restricted_Members
    Inherits System.Web.UI.Page

End Class
