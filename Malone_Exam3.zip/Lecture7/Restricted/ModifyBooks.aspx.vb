﻿
Partial Class Restricted_ModifyBooks
    Inherits System.Web.UI.Page

End Class
