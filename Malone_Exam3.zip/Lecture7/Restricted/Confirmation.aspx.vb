﻿
Partial Class Restricted_Confirmation
    Inherits System.Web.UI.Page

End Class
