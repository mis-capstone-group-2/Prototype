﻿
Partial Class Restricted_ModifyMovies
    Inherits System.Web.UI.Page

End Class
