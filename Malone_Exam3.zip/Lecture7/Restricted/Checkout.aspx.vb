﻿
Partial Class Restricted_Checkout
    Inherits System.Web.UI.Page

End Class
