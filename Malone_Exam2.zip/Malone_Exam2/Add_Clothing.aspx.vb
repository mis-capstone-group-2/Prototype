﻿
Partial Class Add_Clothing
    Inherits System.Web.UI.Page

End Class
