﻿
Partial Class MasterP
    Inherits System.Web.UI.MasterPage
End Class

