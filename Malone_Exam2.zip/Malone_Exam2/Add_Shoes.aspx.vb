﻿
Partial Class Add_Shoes
    Inherits System.Web.UI.Page

End Class
