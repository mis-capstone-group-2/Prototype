﻿
Partial Class Shoes
    Inherits System.Web.UI.Page

End Class
