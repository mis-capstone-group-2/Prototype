﻿
Partial Class Modify_Shoes
    Inherits System.Web.UI.Page

End Class
