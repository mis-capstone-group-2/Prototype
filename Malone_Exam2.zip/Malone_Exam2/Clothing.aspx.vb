﻿
Partial Class Clothing
    Inherits System.Web.UI.Page

End Class
