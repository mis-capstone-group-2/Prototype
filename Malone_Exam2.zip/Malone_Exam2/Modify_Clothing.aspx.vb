﻿
Partial Class Modify_Clothing
    Inherits System.Web.UI.Page

End Class
