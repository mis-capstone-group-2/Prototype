﻿
Partial Class Restricted_ModifyRecords
    Inherits System.Web.UI.Page

End Class
