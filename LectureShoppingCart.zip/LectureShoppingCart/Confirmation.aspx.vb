﻿
Partial Class Confirmation
    Inherits System.Web.UI.Page

End Class
